# AI ChatBot (Python)

A terminal-based chatbot built in Python using OpenAI’s Chat Completion API.  
Created as part of the *Intermediate Programming with Python* sprint at Turing College.

---

## Features

1. Terminal-based AI chat
2. Conversation history support
3. Graceful exit with token usage summary
4. Error handling (quota & context length)
5. Bonus duo mode (Alice & Bob)
6. Unit tests with pytest

---

## Setup

Set your OpenAI API Key:
```
**Windows**

powershell
setx OPENAI_API_KEY "your_api_key_here"

**macOS / Linux**

export OPENAI_API_KEY="your_api_key_here"

```
## Install Dependencies

pip install -r requirements.txt

## Usage
Single chatbot:
python gptbot.py Bobby

Duo Mode:
python gptbot.py duo

## Tests
pytest



