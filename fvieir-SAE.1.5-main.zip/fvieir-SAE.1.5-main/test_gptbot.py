import pytest
from gptbot import (
    is_too_long_error,
    is_quota_error,
    is_topic_command,
)


def test_is_too_long_error():
    assert is_too_long_error(Exception("context length exceeded"))
    assert is_too_long_error(Exception("maximum context reached"))
    assert is_too_long_error(Exception("message too long"))

    assert not is_too_long_error(Exception("quota exceeded"))
    assert not is_too_long_error(Exception("network timeout"))


def test_is_quota_error():
    assert is_quota_error(Exception("insufficient_quota"))
    assert is_quota_error(Exception("Error code: 401"))
    assert not is_quota_error(Exception("timeout"))


def test_is_topic_command():
    ok, topic = is_topic_command("topic: artificial intelligence")
    assert ok is True
    assert topic == "artificial intelligence"

    ok, topic = is_topic_command("hello there")
    assert ok is False

