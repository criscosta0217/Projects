## Part 5: Project - A Chess Question

![playing chess vs a bot](https://i.imgur.com/zdy5TsF.png)

If you compare developers to the general population, you will find that developers are likelier to play (or at least know how) chess. Ignoring the causation/correlation question of this, we will assume that knowing the rules of chess will not hurt your chances of becoming an excellent developer in the long run.

The first practical graded task will require you to implement a Python program to answer a simple question – given a board state that the user enters, with 1 white figure and up to 16 black figures, which black figures can the white figure take?

The criteria you are given to implement are as follows:

1. **Ask the user to input a chess piece and its position**.
 - This will be the **white piece**.
 - The user can choose between two predefined pieces (e.g., pawn or rook).
 - The input should be in the format: `piece coordinates` (e.g., `knight a5`).
 - If the input is invalid (e.g., an unrecognized piece or out-of-bound coordinates), the program should display an error and prompt the user to try again.

2. **Ask the user to input black pieces one by one**.
 - Each input should follow the same format as the white piece: `piece coordinates` (e.g., `pawn d6`).
 - The user must add **at least one black piece** and can add **up to 16 black pieces**.
 - To stop adding pieces, the user can type `done` after adding at least one black piece.
 - If an invalid input is entered (e.g., "pawn z9" or "done" before any black pieces), the program should display an error and ask the user to try again.
 - Duplicate positions are not allowed—if the user tries to place a piece on an already occupied square, an error should be displayed.

3. **Output any black pieces that the white piece can take**.
 - After all pieces are added, the program should analyze the board and print a list of capturable black pieces.
 - Each capturable piece should be displayed by type and coordinates (e.g., "pawn at d4").
 - If no black pieces can be captured, the program should output: "No black pieces can be captured."

You can assume the user will input valid formats for pieces (`piece coordinates`) and coordinates within the board (a-h, 1-8). However, invalid scenarios like duplicate positions or typing "done" too early should be handled gracefully with appropriate error messages.


</br>

## Important Note on Project Requirements

In real-world development, project requirements are often incomplete or ambiguous. This might be due to a lack of time, experience, or the inherent difficulty in predicting all edge cases and functionalities before seeing a working program. As a developer, you will frequently encounter situations where you need to bridge these gaps by:

- Asking follow-up questions to clarify requirements and ensure the program aligns with the intended specifications.
- Making educated assumptions about how the program should function based on the given information.

In this project, if you encounter unclear requirements or uncertain scenarios, make an **educated guess** about how to proceed. Document your assumptions at the end of your Python file as a list of comments to show your thought process and reasoning.

Additionally, if you're unfamiliar with chess, remember that solving problems as a developer often requires learning about the domain in which you are working. For example, developers in the logistics industry benefit from gaining a basic understanding of logistics. Similarly, take this opportunity to learn chess concepts that will help you complete the task.

</br>

## A Notice to Learners

This project is designed to build your programming skills through hands-on practice. While AI tools like GPT can be valuable for guidance or clarifying concepts, relying on them to solve the task entirely will limit your understanding and hinder your growth as a developer.

### Why This Matters

- Programming is a skill best learned through problem-solving and active engagement. By working through challenges, making mistakes, and iterating on solutions, you develop the confidence and intuition to tackle increasingly complex problems.
- Relying on AI for solutions might seem convenient, but it bypasses the learning process that prepares you for real-world scenarios and projects.

### How to Use AI Tools Responsibly

- Use AI to seek **clarifications** or **hints** when you're stuck, but avoid asking for complete solutions.
- If AI provides assistance, take the time to understand the explanations and implement the code yourself. This ensures that you internalize the logic and concepts behind the solution.
- Treat AI as a **supplement to your learning**, not a replacement for hands-on effort. The goal is to engage with the problem, learn from the process, and build a strong foundation for future challenges.
By approaching the project with curiosity, determination, and a willingness to learn, you'll gain a solution to this task and the skills to solve programming problems in the future confidently.

<br>

## Reviewer role

Different projects may require you to structure your presentation in different ways based on the imagined role of the reviewer. The goal is to practice interacting with various stakeholders a developer will likely encounter in their careers.

In this project, imagine that you are introducing your project to a developer team lead in your company. They have technical expertise and will fully understand the work that you have done. You want to demonstrate both that the program works and explain the thought process in the code and writing it. Remember that even when presenting to technical experts, you should ask them if they'd like you to run the code and walk them through the program. Almost always, this is much better than going straight into code.

<br>

# Evaluation Criteria

- The program correctly adds the white piece. Weight: 1
- The program correctly adds the black pieces. Weight: 1
- The program correctly says which black pieces the white piece can take. Weight: 1
- Code quality (at this point, you are expected to write relatively tidy and easy-to-follow code. You can refer to the hands-on suggested solution for the level that may be expected from you). Weight: 1
- General understanding of the sprint topics (the reviewer may ask you about topics covered in the sprint and the code that you have written). Weight: 2

—

During a task review, you may get asked questions that test your understanding of covered topics.

**Sample questions for a reviewer to ask (a reviewer is encouraged and expected to think of more, however!)**

- How do you define a function in Python? How can you easily test whether something is a function in Python? How do you define the parameters of a function?
- What is the difference between a list and a dictionary?
- What is pseudocode?
- Can you show how you debug the program that you have written? Could you make a slight change in the code and explain what it will do?

<br>

## Revision of core Turing College concepts

At Turing College, we focus on cultivating outstanding Python skills for you and the dynamic job market. We maintain high learning standards to ensure you develop robust technical and soft skills, making your skillset highly attractive to current and future employers. Our curriculum emphasizes real-world readiness, often requiring independent research and problem-solving skills in projects. Help is readily available – join open sessions, ask questions on Discord, or during standup.

If you haven't before, read about project reviews and evaluations at Turing College. The quizzes may even contain questions that will test your understanding of these topics.
- [In-depth guide about reviews and evaluation](https://turingcollege.atlassian.net/wiki/x/AgCmcw)

<br>

## Submission and Scheduling a Project Review

To submit the project and allow the reviewer to view your work beforehand, you need to use the Github repository that has been created for you.
Please go through these material to learn more about submitting projects, scheduling project reviews and using Github:

- [Completing a Sprint, Submitting a Project and Scheduling Reviews](https://www.notion.so/Completing-a-Sprint-Submitting-a-Project-and-Scheduling-Reviews-4bdc709c2b7142c8aa7dd06d1d289768?pvs=4)
- [Git and GitHub for Beginners](https://www.youtube.com/watch?v=RGOj5yH7evk)

</br>

**Estimate average time to complete: 10 hours**
