import os
import sys
from openai import OpenAI

MODEL = "gpt-4.1-nano"


def usage():
    """
    Prints usage instructions and exits the program. 
    """
    print("Usage:")
    print("  python gptbot.py <API_KEY> <BOT_NAME>")
    print("  OR (recommended)")
    print("  set OPENAI_API_KEY and run: python gptbot.py <BOT_NAME>")
    print("")
    print("Bonus (duo mode):")
    print("  set OPENAI_API_KEY and run: python gptbot.py duo")
    print("  OR: python gptbot.py <API_KEY> duo")
    raise SystemExit(2)


def parse_args():
    """
    Parses command-line arguments and returns (api_key, bot_name).
    Uses the OPENAI_API_KEY environment variable if no API key is provided.
    """
    # python gptbot.py BOTNAME (API key from env var)
    if len(sys.argv) == 2:
        bot_name = sys.argv[1]
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            print("Error: OPENAI_API_KEY not set and no API key provided.")
            usage()
        return api_key, bot_name

    # python gptbot.py APIKEY BOTNAME
    if len(sys.argv) == 3:
        return sys.argv[1], sys.argv[2]

    usage()


def is_too_long_error(e):
    """
    Returns True if the exception indicates the conversation exceeded 
    the model's maximum context length.
    """
    msg = str(e).lower()
    return (
        "context length" in msg
        or "maximum context" in msg
        or "too long" in msg
    )


def is_quota_error(e):
    """
    Returns True if the exception indicates an API quota or authorization error.
    """
    msg = str(e).lower()
    return (
        "insufficient_quota" in msg
        or "quota" in msg
        or "error code: 401" in msg
    )


def is_topic_command(text):
    """
    Checks whether the input is a valid topic command of the form:
    'topic: <description>'.
    
    Returns (True, topic) if valid, otherwise (False, "").
    """
    # must be: topic: something
    if not text.lower().startswith("topic:"):
        return False, ""
    topic = text[6:].strip()
    if topic == "":
        return False, ""
    return True, topic


def run_chatbot(client, bot_name):
    """
    Runs the interactive single-bot chat loop.
    """
    messages = []
    messages.append({
        "role": "system",
        "content": "You are a helpful assistant. Identify yourself as " + bot_name + "."
    })

    total_tokens = 0

    while True:
        try:
            user_text = input("You: ")
        except EOFError:
            print("Bye!")
            print("Total tokens used:", total_tokens)
            break

        messages.append({"role": "user", "content": user_text})

        try:
            response = client.chat.completions.create(
                model=MODEL,
                messages=messages
            )

            reply = response.choices[0].message.content or ""

            used = 0
            if response.usage and response.usage.total_tokens:
                used = int(response.usage.total_tokens)

            total_tokens += used

            print("AI:", reply)

            messages.append({"role": "assistant", "content": reply})

        except Exception as e:
            if is_too_long_error(e):
                print("Conversation too long for the API.")
                print("Bye!")
                print("Total tokens used:", total_tokens)
                break

            if is_quota_error(e):
                print("Error: API quota exceeded. Please check your plan/billing.")
                print("Bye!")
                print("Total tokens used:", total_tokens)
                break

            print("Error:", e)
            print("Try again (or press Ctrl+D / Ctrl+Z then Enter to quit).")


def run_duo_mode(client):
    """
    Runs the bonus duo mode where two AI personalities (Alice and Bob)
    talk to each other, with optional topic switching.
    """
    alice_system = "You are Alice. You are curious, friendly, and explain clearly. Keep responses fairly short."
    bob_system = "You are Bob. You are skeptical, humorous, and challenge ideas politely. Keep responses fairly short."

    alice_temp = 0.3
    bob_temp = 0.9

    total_tokens = 0
    messages = []
    messages.append({
        "role": "system",
        "content": "Two AIs (Alice and Bob) are having a conversation. Keep it safe, respectful, and on-topic."
    })

    current = "Alice"
    pending_topic = ""

    print("Duo mode started.")
    print("Press Enter for next step.")
    print("Type: topic: <description> to switch topic.")
    print("Exit with Ctrl+D (or Ctrl+Z then Enter).")
    print()

    while True:
        try:
            user_text = input("You (Enter / topic: ...): ")
        except EOFError:
            print("Bye!")
            print("Total tokens used:", total_tokens)
            break

        user_text = user_text.strip()

        if user_text == "":
            pass
        else:
            ok, topic = is_topic_command(user_text)
            if ok:
                pending_topic = topic
            else:
                print('Invalid input. Press Enter for next step, or type: topic: <description>')
                continue

        if current == "Alice":
            speaker_system = alice_system
            temperature = alice_temp
        else:
            speaker_system = bob_system
            temperature = bob_temp

        turn_messages = []
        turn_messages.append({"role": "system", "content": speaker_system})

        if pending_topic:
            turn_messages.append({
                "role": "system",
                "content": "In your next message, try to switch the conversation topic to: " + pending_topic
            })
            pending_topic = ""

        turn_messages.extend(messages)

        try:
            response = client.chat.completions.create(
                model=MODEL,
                messages=turn_messages,
                temperature=temperature
            )

            reply = response.choices[0].message.content or ""

            used = 0
            if response.usage and response.usage.total_tokens:
                used = int(response.usage.total_tokens)
            total_tokens += used

        except Exception as e:
            if is_too_long_error(e):
                print("Conversation too long for the API.")
                print("Bye!")
                print("Total tokens used:", total_tokens)
                break

            if is_quota_error(e):
                print("Error: API quota exceeded. Please check your plan/billing.")
                print("Bye!")
                print("Total tokens used:", total_tokens)
                break

            print("Error:", e)
            print("Try again (or press Ctrl+D / Ctrl+Z then Enter to quit).")
            continue

        print(current + ":", reply)
        print()

        messages.append({"role": "assistant", "content": current + ": " + reply})

        if current == "Alice":
            current = "Bob"
        else:
            current = "Alice"


def main():
    """
    Program entry point. Selects normal or duo mode based on arguments.
    """
    api_key, bot_name = parse_args()
    client = OpenAI(api_key=api_key)

    if bot_name.lower() == "duo":
        run_duo_mode(client)
    else:
        run_chatbot(client, bot_name)


if __name__ == "__main__":
    main()
